# WolfPack Volleyball (PWA build)

This folder is ready for GitHub Pages. Commit the whole folder to a repo and enable Pages.

- **Logo path**: `assets/tru-wolfpack-logo.png`
- **PWA**: `site.webmanifest` + `service-worker.js` included
- **Homescreen**: iOS/Android picks the logo automatically from the manifest & apple-touch-icon

## Deploy on GitHub Pages

1. Push this folder as your repository root (or a `/docs` folder).
2. In *Settings → Pages*, set the source to **main branch** (or `/docs`).
3. Visit your Pages URL and "Add to Home Screen".

## Notes
- If you change the logo filename or path, update it in both `index.html` and `site.webmanifest`.
- The service worker uses a simple cache-first strategy for the shell and logo.